import heapq

maze = [
    ['S', '.', '.', '#', '.', '.', '.'],
    ['.', '#', '.', '#', '.', '#', '.'],
    ['.', '#', '.', '.', '.', '#', '.'],
    ['.', '.', '#', '#', '.', '.', '.'],
    ['#', '.', '.', 'G', '.', '#', '.']
]

ROWS, COLS = len(maze), len(maze[0])

for i in range(ROWS):
    for j in range(COLS):
        if maze[i][j] == 'S':
            start = (i, j)
        elif maze[i][j] == 'G':
            goal = (i, j)

def heuristic(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def neighbors(node):
    r, c = node
    for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
        nr, nc = r+dr, c+dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and maze[nr][nc] != '#':
            yield (nr, nc)

def astar(start, goal):
    pq = [(0, start)]
    came = {}
    g = {start: 0}

    while pq:
        _, cur = heapq.heappop(pq)
        if cur == goal:
            path = [cur]
            while cur in came:
                cur = came[cur]
                path.append(cur)
            return path[::-1]

        for nxt in neighbors(cur):
            ng = g[cur] + 1
            if nxt not in g or ng < g[nxt]:
                g[nxt] = ng
                came[nxt] = cur
                f = ng + heuristic(nxt, goal)
                heapq.heappush(pq, (f, nxt))
    return None

path = astar(start, goal)

if path:
    print("Shortest Path:", path)
    for r,c in path:
        if maze[r][c] not in ('S','G'):
            maze[r][c] = '*'
    print("\nSolved Maze:")
    for row in maze:
        print(" ".join(row))
else:
    print("No path found.")
