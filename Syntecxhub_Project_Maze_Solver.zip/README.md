# Syntecxhub Project 1 - Maze Solver using A* Search

## Objective
Find the shortest path from Start (S) to Goal (G) using the A* Search Algorithm with the Manhattan distance heuristic.

## Requirements
- Python 3.x

## Run
```bash
python maze_solver.py
```

## Files
- maze_solver.py - Main source code
- requirements.txt - Dependencies
- LICENSE - MIT License
- .gitignore - Ignore Python cache

